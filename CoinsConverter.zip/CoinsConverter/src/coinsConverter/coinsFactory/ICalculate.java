package coinsConverter.coinsFactory;
public interface ICalculate {
    double calculate(double value);
}
