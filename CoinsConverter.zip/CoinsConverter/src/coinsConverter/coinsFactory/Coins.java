package coinsConverter.coinsFactory;
public enum Coins {
    USD, ILS
}
